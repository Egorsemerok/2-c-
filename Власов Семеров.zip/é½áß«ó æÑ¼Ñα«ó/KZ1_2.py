def camel(st):
    result = []
    for i, char in enumerate(st):
        if i % 2 == 0:
            result.append(char.upper())
        else:
            result.append(char.lower())
    return ''.join(result)


text = 'Пример'
new_text = camel(text)
print(new_text)